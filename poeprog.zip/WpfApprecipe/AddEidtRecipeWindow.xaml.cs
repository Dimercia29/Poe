﻿using System.Windows;
using System.Windows.Controls;

namespace WpfApprecipe
{
    public partial class AddEditIngredientWindow : Window
    {
        public Ingredient Ingredient { get; private set; }

        public AddEditIngredientWindow()
        {
            InitializeComponent();
            Ingredient = new Ingredient();
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            Ingredient.Name = IngredientNameTextBox.Text;
            if (int.TryParse(CaloriesTextBox.Text, out int calories))
            {
                Ingredient.Calories = calories;
            }
            if (FoodGroupComboBox.SelectedItem is ComboBoxItem selectedFoodGroup)
            {
                Ingredient.FoodGroup = selectedFoodGroup.Content.ToString();
            }
            DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}