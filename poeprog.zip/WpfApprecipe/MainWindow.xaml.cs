﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WpfApprecipe
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            LoadSampleData();
            UpdateRecipeList();
        }

        private void LoadSampleData()
        {
            recipes = new List<Recipe>
            {
                new Recipe
                {
                    Name = "Spaghetti",
                    Ingredients = new List<Ingredient>
                    {
                        new Ingredient { Name = "Spaghetti", Quantity = 200, Unit = "g", Calories = 300, FoodGroup = "Grain" },
                        new Ingredient { Name = "Tomato Sauce", Quantity = 100, Unit = "ml", Calories = 50, FoodGroup = "Vegetable" }
                    }
                },
                new Recipe
                {
                    Name = "Chicken Salad",
                    Ingredients = new List<Ingredient>
                    {
                        new Ingredient { Name = "Chicken", Quantity = 150, Unit = "g", Calories = 250, FoodGroup = "Protein" },
                        new Ingredient { Name = "Lettuce", Quantity = 50, Unit = "g", Calories = 10, FoodGroup = "Vegetable" }
                    }
                }
            };
        }

        private void UpdateRecipeList()
        {
            RecipeListBox.ItemsSource = recipes.Select(r => r.Name).ToList();
        }

        private void RecipeListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (RecipeListBox.SelectedItem != null)
            {
                var selectedRecipe = recipes.FirstOrDefault(r => r.Name == RecipeListBox.SelectedItem.ToString());
                if (selectedRecipe != null)
                {
                    RecipeDetailsTextBlock.Text = selectedRecipe.ToString();
                }
            }
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Implementation for adding a recipe
        }

        private void EditRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Implementation for editing a recipe
        }

        private void DeleteRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem != null)
            {
                var selectedRecipe = recipes.FirstOrDefault(r => r.Name == RecipeListBox.SelectedItem.ToString());
                if (selectedRecipe != null)
                {
                    recipes.Remove(selectedRecipe);
                    UpdateRecipeList();
                }
            }
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            var filteredRecipes = recipes.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(IngredientFilterTextBox.Text))
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients.Any(i => i.Name.Contains(IngredientFilterTextBox.Text, System.StringComparison.OrdinalIgnoreCase)));
            }

            if (FoodGroupComboBox.SelectedItem != null)
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients.Any(i => i.FoodGroup == ((ComboBoxItem)FoodGroupComboBox.SelectedItem).Content.ToString()));
            }

            if (int.TryParse(MaxCaloriesTextBox.Text, out int maxCalories))
            {
                filteredRecipes = filteredRecipes.Where(r => r.Ingredients.Sum(i => i.Calories) <= maxCalories);
            }

            RecipeListBox.ItemsSource = filteredRecipes.Select(r => r.Name).ToList();
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }

        public override string ToString()
        {
            return $"{Name}\nIngredients:\n{string.Join("\n", Ingredients)}\nTotal Calories: {Ingredients.Sum(i => i.Calories)}";
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }

        public override string ToString()
        {
            return $"{Quantity} {Unit} of {Name} ({Calories} calories)";
        }
    }
}